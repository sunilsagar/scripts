#!/bin/bash

process_count=$(ps -ef|grep telegraf | grep -v grep | grep config-directory | wc -l)

if [ "$process_count" == '0' ]; then 
  killall telegraf
  sh telegraf.sh restart
fi
