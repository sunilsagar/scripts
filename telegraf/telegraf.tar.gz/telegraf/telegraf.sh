#! /usr/bin/env bash

TELEGRAF_OPTS=

if [ -r /lib/lsb/init-functions ]; then
    source /lib/lsb/init-functions
fi

if [ -z "$STDOUT" ]; then
    STDOUT='logs/telegraf_stdout.log'
fi
if [ ! -f "$STDOUT" ]; then
    mkdir -p `dirname $STDOUT`
fi

if [ -z "$STDERR" ]; then
    STDERR='logs/telegraf_stderr.log'
fi
if [ ! -f "$STDERR" ]; then
    mkdir -p `dirname $STDERR`
fi

OPEN_FILE_LIMIT=2000

function pidofproc() {
    if [ $# -ne 3 ]; then
        echo "Expected three arguments, e.g. $0 -p pidfile daemon-name"
    fi

    if [ ! -f "$2" ]; then
        return 1
    fi

    local pidfile=`cat $2`

    if [ "x$pidfile" == "x" ]; then
        return 1
    fi

    if ps --pid "$pidfile" | grep -q $(basename $3); then
        return 0
    fi

    return 1
}

function log_failure_msg() {
    echo "$@" "[ FAILED ]"
}

function log_success_msg() {
    echo "$@" "[ OK ]"
}

# Process name ( For display )
name=telegraf

# Daemon name, where is the actual executable
daemon=bin/telegraf

# pid file for the daemon
pidfile=var/run/telegraf.pid
piddir=`dirname $pidfile`

if [ ! -d "$piddir" ]; then
    mkdir -p $piddir
    chown $USER:$GROUP $piddir
fi

# Configuration file
config=conf/telegraf.conf
confdir=conf/telegraf.d

# If the daemon is not there, then exit.
[ -x $daemon ] || exit 5

case $1 in
    start)
        # Checked the PID file exists and check the actual status of process
        if [ -e "$pidfile" ]; then
            if pidofproc -p $pidfile $daemon > /dev/null; then
                log_failure_msg "$name process is running"
                exit 0
            fi
        fi

        # Bump the file limits, before launching the daemon. These will carry over to
        # launched processes.
        ulimit -n $OPEN_FILE_LIMIT 2> /dev/null
        log_success_msg "Starting the process" "$name"
        nohup $daemon -pidfile $pidfile -config $config -config-directory $confdir $TELEGRAF_OPTS >>$STDOUT 2>>$STDERR &
        log_success_msg "$name process was started"
        ;;

    stop)
        log_success_msg "Stopping the process" "$name"
        killproc -p $pidfile SIGTERM 2>&1 >/dev/null
        sleep 2

        log_success_msg "$name process was stopped"
        rm -f $pidfile
        ;;

    restart)
        # Restart the daemon.
        sh $0 stop && sleep 2 && sh $0 start
        ;;

    status)
        # Check the status of the process.
        if [ -e $pidfile ]; then
            if pidofproc -p $pidfile $daemon > /dev/null; then
                log_success_msg "$name Process is running"
                exit 0
            else
                log_failure_msg "$name Process is not running"
                exit 1
            fi
        else
            log_failure_msg "$name Process is not running"
            exit 3
        fi
        ;;

    version)
        $daemon version
        ;;

    *)
        # For invalid arguments, print the usage message.
        echo "Usage: $0 {start|stop|restart|status|version}"
        exit 2
        ;;
esac
